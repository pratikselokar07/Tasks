import csv

# Created the employee personal information
with open('employee_personal_data.csv', 'w', newline='') as a:
    fieldnames = ['emp_id', 'emp_fullname', 'emp_age', 'emp_gender', 'emp_mobile', 'emp_address', 'emp_email']
    writer = csv.DictWriter(a, fieldnames=fieldnames)

    writer.writeheader()
    writer.writerow(
        {'emp_id': 1, 'emp_fullname': 'Pratik Selokar', 'emp_age': 23, 'emp_gender': 'M', 'emp_mobile': '7558765456',
         'emp_address': 'Sakoli', 'emp_email': 'pratikselokar@gmail.com'})
    writer.writerow(
        {'emp_id': 2, 'emp_fullname': 'Rahul Kumar', 'emp_age': 24, 'emp_gender': 'M', 'emp_mobile': '7965841236',
         'emp_address': 'Patna', 'emp_email': 'rk.sk@gmail.com'})

# Created the employee company details
with open('employee_company_details.csv', 'w', newline='') as b:
    fieldnames = ['emp_id', 'emp_designation', 'emp_joined', 'emp_status', 'emp_department']
    w = csv.DictWriter(b, fieldnames=fieldnames)

    w.writeheader()

    w.writerow({'emp_id': 1, 'emp_designation': 'Fresher', 'emp_joined': '2020-12-28', 'emp_status': 'Active',
                'emp_department': 'Dev'})
    w.writerow({'emp_id': 2, 'emp_designation': 'Hr', 'emp_joined': '2022-09-24', 'emp_status': 'Active',
                'emp_department': 'Market'})

# Created the employee salary details
with open('employee_salary_details.csv', 'w', newline='') as c:
    fieldnames = ['emp_id', 'emp_salary', 'emp_net_salary', 'emp_tax', 'emp_pf', 'emp_health_amount']
    w = csv.DictWriter(c, fieldnames=fieldnames)

    w.writeheader()

    w.writerow({'emp_id': 1, 'emp_salary': 30000, 'emp_net_salary': 40000, 'emp_tax': 10000, 'emp_pf': 5000,
                'emp_health_amount': 500})
    w.writerow({'emp_id': 2, 'emp_salary': 25000, 'emp_net_salary': 35000, 'emp_tax': 10000, 'emp_pf': 5000,
                'emp_health_amount': 500})

print("CSV File created")

# Read ing
with open('employee_personal_data.csv', 'r') as a:
    r = csv.DictReader(a)
    personal_data = list(r)

# Reading
with open('employee_company_details.csv', 'r') as b:
    r = csv.DictReader(b)
    company_data = list(r)

# Reading
with open('employee_salary_details.csv', 'r') as c:
    r = csv.DictReader(c)
    salary_data = list(r)

# Merging
employee_data = []
for personal in personal_data:
    emp_id = personal['emp_id']
    employee = personal
    for com in company_data:
        if com['emp_id'] == emp_id:
            employee.update(com)
            break
    for sal in salary_data:
        if sal['emp_id'] == emp_id:
            employee.update(sal)
            break
    employee_data.append(employee)

# Writing new data
with open('employee_details.csv', 'w', newline='') as a:
    fieldnames = ['emp_id', 'emp_fullname', 'emp_age', 'emp_gender', 'emp_mobile', 'emp_address', 'emp_email',
                  'emp_designation', 'emp_joined', 'emp_status', 'emp_department', 'emp_salary', 'emp_net_salary',
                  'emp_tax', 'emp_pf', 'emp_health_amount']
    w = csv.DictWriter(a, fieldnames=fieldnames)

    w.writeheader()
    w.writerows(employee_data)

with open('employee_details.csv', 'r') as csvfile:
    reader = csv.DictReader(csvfile)
    print("Data of merge file\n")
    for row in reader:
        print(row)

# open the input file
with open('employee_details.csv', 'r') as f:
    # create a CSV reader for the input file
    u = csv.DictReader(f)

    # find the highest salary
    highest_salary = 0
    for row in u:
        salary = int(row['emp_salary'])
        if salary > highest_salary:
            highest_salary = salary
            highest_salary_emp=row


print("\nHighest Salary Employyee Details\n")
print(highest_salary_emp)