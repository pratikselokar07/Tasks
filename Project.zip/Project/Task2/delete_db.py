import json
import mysql.connector

# Load the JSON data from the file
with open('userinfo.json', 'r') as f:
    data = json.load(f)

# Connect to the database
con = mysql.connector.connect(host='localhost',user='root', password='Tiger@123',  database='mydatabase')
cursor = con.cursor()


def delete():

    e=input("Enter Email_id: ")
    cursor = con.cursor()
    query = f"SELECT * FROM userinfo WHERE email='{e}'"
    cursor.execute(query)

    for item in data['details']:
        if cursor.fetchone():
            print("Value found in database")
            query = f"DELETE FROM userinfo WHERE email = '{e}'"
            cursor.execute(query)
            print("Deleted Successfully")
            con.commit()
            break
        else:
            print("Value not found in database")
            break

cursor.close()
delete()

