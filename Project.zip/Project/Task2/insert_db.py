import json
import mysql.connector

# Load the JSON data from the file
with open('userinfo.json', 'r') as f:
    data = json.load(f)

# Connect to the database
con = mysql.connector.connect(host='localhost',user='root', password='Tiger@123',  database='mydatabase')
cursor = con.cursor()
def insert():
    cursor = con.cursor()

    with open('userinfo.json', 'r') as f:
        data = json.load(f)

    for item in data['details']:
        query = "INSERT INTO userinfo (firstname, lastname, email, mobileno, address) VALUES (%s, %s, %s, %s, %s)"
        values = (item['firstname'], item['lastname'], item['email'], item['mobileno'], item['address'])
        cursor.execute(query, values)
    print("record Success")
    con.commit()
    con.close()
insert()