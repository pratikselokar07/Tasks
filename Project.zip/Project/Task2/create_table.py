import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="Tiger@123",
  database="mydatabase"
)

mycursor = mydb.cursor()
mycursor.execute("CREATE TABLE userinfo (firstname VARCHAR(255), lastname VARCHAR(255), email VARCHAR(255), mobileno VARCHAR(255), address VARCHAR(255))")
print("Table created Successfully")